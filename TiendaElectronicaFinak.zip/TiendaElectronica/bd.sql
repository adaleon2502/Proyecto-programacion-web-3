-- Crear base de datos
CREATE DATABASE IF NOT EXISTS tienda_electronica_db;
USE tienda_electronica_db;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol ENUM('admin','cliente') DEFAULT 'admin',
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de productos
CREATE TABLE IF NOT EXISTS productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  descripcion VARCHAR(255),
  precio DECIMAL(10,2) NOT NULL,
  categoria VARCHAR(100),
  stock INT DEFAULT 0,
  activo TINYINT(1) DEFAULT 1, -- 1 = activo, 0 = eliminado lógicamente
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de logs de acceso
CREATE TABLE IF NOT EXISTS logs_acceso (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT,
  accion VARCHAR(50),  -- 'login' o 'logout'
  navegador VARCHAR(255),
  fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
