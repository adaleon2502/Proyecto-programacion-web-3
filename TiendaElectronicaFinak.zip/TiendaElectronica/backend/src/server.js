// src/server.js
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import '../src/config/db.js';
import UsuarioRutas from './Rutas/UsuarioRutas.js';
import productosRoutes from './Rutas/productosRutas.js';
import logRoutes from './Rutas/logRutas.js';

const app = express();

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.use('/api/auth', UsuarioRutas);
app.use('/api/productos', productosRoutes);
app.use('/api/logs', logRoutes);

app.get('/', (req, res) => {
  res.send('API Tienda Electrónica funcionando');
});

const puerto = 3001;

app.listen(puerto, () => {
  console.log(`Servidor en http://localhost:${puerto}`);
});
