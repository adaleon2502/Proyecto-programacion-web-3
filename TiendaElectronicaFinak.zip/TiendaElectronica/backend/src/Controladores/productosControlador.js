
import { db } from '../config/db.js';
import { validationResult } from 'express-validator';
import { generarPdfProductos } from '../PDF/generarPDF.js';

export const obtenerProductos = (req, res) => {
  const q = 'SELECT * FROM productos WHERE activo = 1';
  db.query(q, (err, data) => {
    if (err) return res.status(500).json(err);
    return res.json(data);
  });
};

export const crearProducto = (req, res) => {
  const errores = validationResult(req);
  if (!errores.isEmpty()) {
    return res.status(400).json({ errores: errores.array() });
  }

  const { nombre, descripcion, precio, categoria, stock } = req.body;

  const q =
    'INSERT INTO productos (nombre, descripcion, precio, categoria, stock) VALUES (?)';
  const valores = [nombre, descripcion || '', precio, categoria || '', stock || 0];

  db.query(q, [valores], (err, data) => {
    if (err) return res.status(500).json(err);
    return res.json({ mensaje: 'Producto creado correctamente' });
  });
};

export const actualizarProducto = (req, res) => {
  const errores = validationResult(req);
  if (!errores.isEmpty()) {
    return res.status(400).json({ errores: errores.array() });
  }

  const { id } = req.params;
  const { nombre, descripcion, precio, categoria, stock } = req.body;

  const q =
    'UPDATE productos SET nombre = ?, descripcion = ?, precio = ?, categoria = ?, stock = ? WHERE id = ? AND activo = 1';

  db.query(
    q,
    [nombre, descripcion || '', precio, categoria || '', stock || 0, id],
    (err, data) => {
      if (err) return res.status(500).json(err);
      return res.json({ mensaje: 'Producto actualizado' });
    }
  );
};

export const eliminarLogicoProducto = (req, res) => {
  const { id } = req.params;

  const q = 'UPDATE productos SET activo = 0 WHERE id = ?';

  db.query(q, [id], (err, data) => {
    if (err) return res.status(500).json(err);
    return res.json({ mensaje: 'Producto eliminado lógicamente' });
  });
};

export const reporteProductosPdf = (req, res) => {
  const q = 'SELECT * FROM productos WHERE activo = 1';

  db.query(q, (err, data) => {
    if (err) return res.status(500).json(err);
    generarPdfProductos(res, data);
  });
};
