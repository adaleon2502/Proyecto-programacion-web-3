// src/controllers/authController.js
import { db } from '../config/db.js';
import bcrypt from 'bcrypt';
import { validationResult } from 'express-validator';
import { generarToken } from '../Modelo/UsuarioModelo.js';

export const registrarUsuario = (req, res) => {
  const errores = validationResult(req);
  if (!errores.isEmpty()) {
    return res.status(400).json({ errores: errores.array() });
  }

  const { nombre, email, password, rol } = req.body;

  const qBuscar = 'SELECT * FROM usuarios WHERE email = ?';
  db.query(qBuscar, [email], async (err, data) => {
    if (err) return res.status(500).json(err);
    if (data.length > 0) {
      return res.status(400).json({ mensaje: 'El email ya está registrado' });
    }

    const hash = await bcrypt.hash(password, 10);

    const qInsert =
      'INSERT INTO usuarios (nombre, email, password, rol) VALUES (?)';
    const valores = [nombre, email, hash, rol || 'admin'];

    db.query(qInsert, [valores], (err2, data2) => {
      if (err2) return res.status(500).json(err2);
      return res.json({ mensaje: 'Usuario registrado correctamente' });
    });
  });
};

export const loginUsuario = (req, res) => {
  const errores = validationResult(req);
  if (!errores.isEmpty()) {
    return res.status(400).json({ errores: errores.array() });
  }

  const { email, password } = req.body;

  const q = 'SELECT * FROM usuarios WHERE email = ?';
  db.query(q, [email], async (err, data) => {
    if (err) return res.status(500).json(err);
    if (data.length === 0) {
      return res.status(400).json({ mensaje: 'Credenciales incorrectas' });
    }

    const usuario = data[0];
    const coincide = await bcrypt.compare(password, usuario.password);

    if (!coincide) {
      return res.status(400).json({ mensaje: 'Credenciales incorrectas' });
    }

    const token = generarToken(usuario);

    // registrar log de login
    const navegador = req.headers['user-agent'] || 'desconocido';
    const qLog =
      'INSERT INTO logs_acceso (usuario_id, accion, navegador) VALUES (?, ?, ?)';
    db.query(qLog, [usuario.id, 'login', navegador]);

    return res.json({
      mensaje: 'Login correcto',
      token,
      usuario: {
        id: usuario.id,
        nombre: usuario.nombre,
        email: usuario.email,
        rol: usuario.rol
      }
    });
  });
};

export const logoutUsuario = (req, res) => {
  const usuarioId = req.usuario.id;
  const navegador = req.headers['user-agent'] || 'desconocido';

  const q =
    'INSERT INTO logs_acceso (usuario_id, accion, navegador) VALUES (?, ?, ?)';
  db.query(q, [usuarioId, 'logout', navegador], (err) => {
    if (err) {
      console.log(err);
    }
    return res.json({ mensaje: 'Logout registrado' });
  });
};

