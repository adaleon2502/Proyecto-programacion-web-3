// src/controllers/logController.js
import { db } from '../config/db.js';

export const obtenerLogs = (req, res) => {
  const q =
    'SELECT l.id, u.nombre, u.email, l.accion, l.navegador, l.fecha ' +
    'FROM logs_acceso l LEFT JOIN usuarios u ON l.usuario_id = u.id ' +
    'ORDER BY l.fecha DESC';

  db.query(q, (err, data) => {
    if (err) return res.status(500).json(err);
    return res.json(data);
  });
};

