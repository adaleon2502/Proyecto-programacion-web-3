
import jwt from 'jsonwebtoken';

const CLAVE_SECRETA = 'mi_clave_secreta_super_simple';

export const verificarToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader) {
    return res.status(401).json({ mensaje: 'No se envió token' });
  }

  const token = authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ mensaje: 'Token inválido' });
  }

  try {
    const decoded = jwt.verify(token, CLAVE_SECRETA);
    req.usuario = decoded; // { id, nombre, rol }
    next();
  } catch (error) {
    return res.status(401).json({ mensaje: 'Token no válido' });
  }
};

export const generarToken = (usuario) => {
  const payload = {
    id: usuario.id,
    nombre: usuario.nombre,
    rol: usuario.rol
  };

  return jwt.sign(payload, CLAVE_SECRETA, { expiresIn: '2h' });
};

