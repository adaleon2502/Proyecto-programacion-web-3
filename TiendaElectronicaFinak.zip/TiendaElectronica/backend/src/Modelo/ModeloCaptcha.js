// src/middleware/captchaMiddleware.js
export const verificarCaptcha = (req, res, next) => {
  const { captcha } = req.body;

  if (!captcha || captcha !== '1234') {
    return res.status(400).json({ mensaje: 'Captcha incorrecto' });
  }

  next();
};

