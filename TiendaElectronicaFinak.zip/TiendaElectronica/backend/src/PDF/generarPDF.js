
import PDFDocument from 'pdfkit';

export const generarPdfProductos = (res, productos) => {
  const doc = new PDFDocument();

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename=reporte_productos.pdf');

  doc.pipe(res);

  doc.fontSize(18).text('Reporte de productos activos', { align: 'center' });
  doc.moveDown();

  productos.forEach((p) => {
    doc
      .fontSize(12)
      .text(`ID: ${p.id}  Nombre: ${p.nombre}`)
      .text(`Categoria: ${p.categoria}  Precio: ${p.precio}  Stock: ${p.stock}`)
      .text('--------------------------------------------------------')
      .moveDown(0.5);
  });

  doc.end();
};
