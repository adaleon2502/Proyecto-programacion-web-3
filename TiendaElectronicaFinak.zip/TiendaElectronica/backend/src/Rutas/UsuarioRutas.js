// src/routes/authRoutes.js
import { Router } from 'express';
import { body } from 'express-validator';
import {
  registrarUsuario,
  loginUsuario,
  logoutUsuario
} from '../Controladores/UsuarioControlador.js';
import { verificarCaptcha } from '../Modelo/ModeloCaptcha.js';
import { verificarToken } from '../Modelo/UsuarioModelo.js';

const router = Router();

router.post(
  '/registro',
  [
    body('nombre').notEmpty().withMessage('El nombre es obligatorio'),
    body('email').isEmail().withMessage('Email no válido'),
    body('password')
      .isLength({ min: 6 })
      .withMessage('La contraseña debe tener al menos 6 caracteres')
  ],
  verificarCaptcha,
  registrarUsuario
);

router.post(
  '/login',
  [
    body('email').isEmail().withMessage('Email no válido'),
    body('password').notEmpty().withMessage('La contraseña es obligatoria')
  ],
  verificarCaptcha,
  loginUsuario
);

router.post('/logout', verificarToken, logoutUsuario);

export default router;
