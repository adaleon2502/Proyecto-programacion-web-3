// src/routes/logRoutes.js
import { Router } from 'express';
import { obtenerLogs } from '../Controladores/logControlador.js';
import { verificarToken } from '../Modelo/UsuarioModelo.js';

const router = Router();

router.get('/', verificarToken, obtenerLogs);

export default router;
