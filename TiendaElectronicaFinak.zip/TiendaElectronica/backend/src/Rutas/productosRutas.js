// src/routes/productosRoutes.js
import { Router } from 'express';
import { body } from 'express-validator';
import {
  obtenerProductos,
  crearProducto,
  actualizarProducto,
  eliminarLogicoProducto,
  reporteProductosPdf,
  estadisticaProductosPorCategoria
} from '../Controladores/productosControlador.js';
import { verificarToken } from '../Modelo/UsuarioModelo.js';

const router = Router();

router.get('/', verificarToken, obtenerProductos);

router.post(
  '/',
  verificarToken,
  [
    body('nombre').notEmpty().withMessage('El nombre es obligatorio'),
    body('precio').isFloat({ min: 0 }).withMessage('Precio no válido'),
    body('stock').isInt({ min: 0 }).withMessage('Stock no válido')
  ],
  crearProducto
);

router.put(
  '/:id',
  verificarToken,
  [
    body('nombre').notEmpty().withMessage('El nombre es obligatorio'),
    body('precio').isFloat({ min: 0 }).withMessage('Precio no válido'),
    body('stock').isInt({ min: 0 }).withMessage('Stock no válido')
  ],
  actualizarProducto
);

router.delete('/:id', verificarToken, eliminarLogicoProducto);

router.get('/reporte/pdf', verificarToken, reporteProductosPdf);

router.get(
  '/estadisticas/categorias',
  verificarToken,
  estadisticaProductosPorCategoria
);

export default router;
