function NavBar({ setUsuario, setPagina, pagina }) {
  const logout = () => {
    setUsuario(null);
    setPagina("productos");
  };

  return (
    <div className="navbar">
      <button
        className={pagina === "productos" ? "active" : ""}
        onClick={() => setPagina("productos")}
      >
        Productos
      </button>

      <button onClick={logout}>Salir</button>
    </div>
  );
}

export default NavBar;
