// src/App.jsx
import "./App.css";

import { useState } from "react";
import Login from "./pages/Login";
import Registro from "./pages/Registro";
import Productos from "./pages/Productos";
import NavBar from "./components/NavBar";

function App() {
  const [usuario, setUsuario] = useState(null);
  const [token, setToken] = useState("");
  const [pagina, setPagina] = useState("productos");

  // Vista de login/registro
  if (!usuario) {
    return (
      <div className="page">
        <div className="page-content">
          <Login setUsuario={setUsuario} setToken={setToken} />
          <hr />
          <Registro />
        </div>
      </div>
    );
  }

  // Vista interna con menú
  return (
    <div className="page">
      <NavBar
        setUsuario={setUsuario}
        setPagina={setPagina}
        pagina={pagina}
      />

      <div className="page-content">
        {pagina === "productos" && <Productos token={token} />}
      </div>
    </div>
  );
}

export default App;
