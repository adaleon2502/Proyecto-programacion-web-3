import { useState, useEffect } from 'react';
import { api } from '../services/api.jsx';

function App({ id,token }) {

  const [productos, guardarRep] = useState({
    nombre: '',
    descripcion: '',
    precio: '',
    categoria: '',
    stock: ''
  });


  function leeRep(e) {
    guardarRep({
      ...productos,
      [e.target.name]: e.target.value
    });
  }

  async function consultaRep(token) {
    try {
      const resultado = await api.get(`/productos/${id}`, token);
      guardarRep(resultado);
    } catch (error) {
      console.log("Error al cargar el producto:", error);
    }
  }

  async function actualizaRep(e) {
    e.preventDefault();
   
    const precioNum = Number(
      productos.precio);
    const stockNum = Number(productos.stock);

    try {
      const resultado = await api.put(
        `/productos/${id}`,
        {
          ...productos,
          precio: precioNum,
          stock: stockNum
        },
        token
      );

      console.log(resultado);
      alert("Producto actualizado correctamente ✅");

    } catch (error) {
      console.log("Error al actualizar:", error);
    }
  }

  useEffect(() => {
    if (token) {
      consultaRep(token);
    } else {
       console.log(token)
      alert("No hay token, debes iniciar sesión");
    }
  }, [id]);

  return (
    <>
      <h2>Editar Producto</h2>

      <form onSubmit={actualizaRep}>
        <div>
          <label>Nombre:</label>
          <input
            type="text"
            name="nombre"
            placeholder="Nombre"
            value={productos.nombre}
            onChange={leeRep}
          />
        </div>

        <div>
          <label>Descripcion:</label>
          <input
            type="text"
            name="descripcion"
            placeholder="Descripcion"
            value={productos.descripcion}
            onChange={leeRep}
          />
        </div>

        <div>
          <label>Precio:</label>
          <input
            type="number"
            name="precio"
            placeholder="Precio"
            min="0"
            value={productos.precio}
            onChange={leeRep}
          />
        </div>

        <div>
          <label>Categoria:</label>
          <input
            type="text"
            name="categoria"
            placeholder="Categoria"
            value={productos.categoria}
            onChange={leeRep}
          />
        </div>

        <div>
          <label>Stock:</label>
          <input
            type="number"
            name="stock"
            placeholder="Stock"
            min="0"
            value={productos.stock}
            onChange={leeRep}
          />
        </div>

        <button type="submit">Actualizar</button>
      </form>
    </>
  );
}

export default App;