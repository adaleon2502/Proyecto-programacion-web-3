// src/pages/Login.jsx
import { useState } from "react";
import { api } from "../services/api.jsx";

function Login({ setUsuario, setToken }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [captcha, setCaptcha] = useState("");
  const [error, setError] = useState("");

  const login = async (e) => {
    e.preventDefault();
    setError("");

    if (!email || !password || !captcha) {
      setError("Complete todos los campos.");
      return;
    }

    if (captcha !== "1234") {
      setError("El captcha debe ser 1234.");
      return;
    }

    const data = await api.post("/auth/login", {
      email,
      password,
      captcha
    });

    if (data.token) {
      setUsuario(data.usuario);
      setToken(data.token);
    } else {
      setError(data.mensaje || "Credenciales incorrectas.");
    }
  };

  return (
    <div className="card">
      <h2>Acceso</h2>
      <form onSubmit={login} className="form">
        <input
          type="email"
          placeholder="Correo"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <input
          type="text"
          placeholder="Captcha: escribe 1234"
          value={captcha}
          onChange={(e) => setCaptcha(e.target.value)}
        />

        {error && <p className="error">{error}</p>}

        <button type="submit">Ingresar</button>
      </form>
    </div>
  );
}

export default Login;
