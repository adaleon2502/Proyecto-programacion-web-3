// src/pages/Registro.jsx
import { useState } from "react";
import { api } from "../services/api.jsx";

function clasificarPassword(pass) {
  if (pass.length < 6) return "Muy débil";
  if (pass.length <= 8) return "Débil";
  if (pass.length <= 12) return "Media";
  return "Fuerte";
}

function Registro() {
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [captcha, setCaptcha] = useState("");
  const [error, setError] = useState("");
  const [mensaje, setMensaje] = useState("");

  const registrar = async (e) => {
    e.preventDefault();
    setError("");
    setMensaje("");

    if (!nombre || !email || !password || !captcha) {
      setError("Complete todos los campos.");
      return;
    }

    if (captcha !== "1234") {
      setError("El captcha debe ser 1234.");
      return;
    }

    if (password.length < 6) {
      setError("La contraseña debe tener mínimo 6 caracteres.");
      return;
    }

    const data = await api.post("/auth/registro", {
      nombre,
      email,
      password,
      captcha
    });

    if (data.mensaje) {
      setMensaje(data.mensaje);
      setNombre("");
      setEmail("");
      setPassword("");
      setCaptcha("");
    } else {
      setError(data.mensaje || "Error al registrar.");
    }
  };

  const fuerza = clasificarPassword(password);

  return (
    <div className="card">
      <h2>Registro</h2>
      <form onSubmit={registrar} className="form">
        <input
          placeholder="Nombre"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />

        <input
          type="email"
          placeholder="Correo"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        {password && (
          <p className="info">
            Fuerza de la contraseña: <b>{fuerza}</b>
          </p>
        )}

        <input
          placeholder="Captcha: 1234"
          value={captcha}
          onChange={(e) => setCaptcha(e.target.value)}
        />

        {error && <p className="error">{error}</p>}
        {mensaje && <p className="ok">{mensaje}</p>}

        <button type="submit">Crear cuenta</button>
      </form>
    </div>
  );
}

export default Registro;
