// src/pages/Productos.jsx
import { useState, useEffect } from "react";
import { api } from "../services/api.jsx";
import EditarProducto from "../pages/EditarProducto.jsx"

function Productos({ token }) {
  const [productos, setProductos] = useState([]);
  const [form, setForm] = useState({
    nombre: "",
    descripcion: "",
    precio: "",
    categoria: "",
    stock: ""
  });
  const [editar, setEditar] = useState(false);
  const [error, setError] = useState("");
  const [id, setID] = useState([]);

  const cargar = async () => {
    const data = await api.get("/productos", token);
    setProductos(data);
  };

  useEffect(() => {
    cargar();
  }, []);

  const crear = async () => {
    setError("");

    if (!form.nombre || !form.precio || !form.categoria) {
      setError("Nombre, precio y categoría son obligatorios.");
      return;
    }

    const precioNum = parseFloat(form.precio);
    const stockNum = parseInt(form.stock || 0);

    if (isNaN(precioNum) || precioNum <= 0) {
      setError("El precio debe ser un número mayor a 0.");
      return;
    }

    if (isNaN(stockNum) || stockNum < 0) {
      setError("El stock debe ser un número mayor o igual a 0.");
      return;
    }

    await api.post(
      "/productos",
      {
        ...form,
        precio: precioNum,
        stock: stockNum
      },
      token
    );

    setForm({
      nombre: "",
      descripcion: "",
      precio: "",
      categoria: "",
      stock: ""
    });

    cargar();
  };

  const eliminar = async (id) => {
    await api.delete(`/productos/${id}`, token);
    cargar();
  };

  if (editar) {
      return <EditarProducto id = {id} token={token} />
  };

  const descargarPdf = async () => {
    try {
      const res = await fetch(
        "http://localhost:3001/api/productos/reporte/pdf",
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      if (!res.ok) {
        alert("No se pudo generar el PDF.");
        return;
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = url;
      link.download = "Reporte_Productos.pdf";

      document.body.appendChild(link);
      link.click();
      link.remove();

      window.URL.revokeObjectURL(url);

      alert("PDF generado correctamente 🎉");
    } catch (err) {
      console.error(err);
      alert("Error al generar el PDF.");
    }
  };

  return (
    <div className="card">
      <h2>Productos</h2>

      <div className="form">
        <input
          placeholder="Nombre"
          value={form.nombre}
          onChange={(e) => setForm({ ...form, nombre: e.target.value })}
        />

        <input
          placeholder="Descripción"
          value={form.descripcion}
          onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
        />

        <input
          placeholder="Precio"
          value={form.precio}
          onChange={(e) => setForm({ ...form, precio: e.target.value })}
        />

        <input
          placeholder="Categoría"
          value={form.categoria}
          onChange={(e) => setForm({ ...form, categoria: e.target.value })}
        />

        <input
          placeholder="Existencias"
          value={form.stock}
          onChange={(e) => setForm({ ...form, stock: e.target.value })}
        />

        {error && <p className="error">{error}</p>}

        <div className="buttons-row">
          <button onClick={crear}>Guardar</button>
          <button onClick={descargarPdf}>Descargar PDF</button>
        </div>
      </div>

      <hr />

      {/* LISTADO DE PRODUCTOS */}
      <div className="productos-container">
        {productos.map((p) => (
          <div key={p.id} className="producto-item">
            <div className="producto-info">
              <b>{p.nombre}</b> – {p.categoria} – ${p.precio} – Stock: {p.stock}
            </div>

            <div className="producto-actions">
              <button className="btn-editar" onClick = {() => {
            setEditar(true);
            setID(p.id)
            }}>Editar</button>
              <button
                className="btn-eliminar"
                onClick={() => eliminar(p.id)}
              >
                Eliminar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Productos;
